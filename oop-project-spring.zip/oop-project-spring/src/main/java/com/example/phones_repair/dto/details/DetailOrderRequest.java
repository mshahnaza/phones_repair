package com.example.phones_repair.dto.details;

public class DetailOrderRequest {
    private String detail_name;

    public String getDetail_name() {
        return detail_name;
    }

    public void setDetail_name(String detail_name) {
        this.detail_name = detail_name;
    }
}
