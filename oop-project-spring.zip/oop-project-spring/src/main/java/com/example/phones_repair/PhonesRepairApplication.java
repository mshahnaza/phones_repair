package com.example.phones_repair;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PhonesRepairApplication {

	public static void main(String[] args) {
		SpringApplication.run(PhonesRepairApplication.class, args);
	}

}
